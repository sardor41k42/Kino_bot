
from aiogram import Router
router = Router()

# Render.com webhook holatida kanaldan yangilik olish uchun bu alohida yoziladi
