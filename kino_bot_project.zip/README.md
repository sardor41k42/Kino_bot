# Kino Bot
Bu Telegram kino bot Railway uchun tayyorlangan. Bot /start komandasi bilan ishlaydi.

## Foydalanish:
1. `.env` fayl yarating va `TOKEN=` qiymatini yozing.
2. Railway yoki boshqa xostingda deploy qiling.
