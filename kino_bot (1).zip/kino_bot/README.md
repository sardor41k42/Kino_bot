
# Kino Qidiruv Telegram Bot

📽 Bu Telegram bot foydalanuvchilarga kanalga qo‘shilgan kinolarni avtomatik yuboradi, qidiruv funksiyasiga ega va admin bilan bog‘lanish imkoniyatini beradi.

## Funktsiyalar
- /start bilan boshlash
- Foydalanuvchini ro‘yxatga olish
- Kanalga post chiqqanda avtomatik yuborish
- Kino nomi yoki kodi bilan qidirish
- Inline qidiruv
- Admin bilan bog‘lanish tugmasi
- Reklama uchun kontakt

🎬 Admin kontakt: @Usernem_bor
